package com.tzy.onlineweb.util;

import com.tzy.onlineweb.entity.UserBase;

public class ShareData {
	
	private ShareData() {
		
		
	}
	
	//会话用户
	public static UserBase sessionUserBase=null;

}
