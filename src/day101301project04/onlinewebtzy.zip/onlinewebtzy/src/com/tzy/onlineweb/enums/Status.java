package com.tzy.onlineweb.enums;

public enum Status {

	FAIL(0,"失败"),SUCCESS(1,"成功"),EXIST(2,"存在");
	
	private Status(int key,String value) {
		
		
	}
	
}
